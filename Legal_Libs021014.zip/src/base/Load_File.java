package base;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

//import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Statement;

import javax.swing.JOptionPane;

//import oracle.jdbc.pool.OracleDataSource;

public class Load_File {

	//Acts like a global variable and is referenced in other packages as Load_File.lTest
	public final static boolean lTest = true;
	//Set to false when testing and you do not want email sent
	public final static boolean lEmail = false;

	
	
	//public void main(String[] args, Object String) throws IOException {
	public static void main(String[] args) throws IOException, SQLException {

		//Added to create a log for email being sent
		Logger logger = null;

		try {
			boolean append = true;
			FileHandler fh = new FileHandler("CMFT_Mail.log", append);
			//fh.setFormatter(new XMLFormatter());
			fh.setFormatter(new SimpleFormatter());
			logger = Logger.getLogger("log_name");
			logger.addHandler(fh);
		}
		catch (IOException e) {
			e.printStackTrace();
		}

		logger.info("Running CMFT");

		
		if (Load_File.lTest) System.out.println("Begin Load_File"); 


		//***************************************************************************************************
		//Database connection statements
		//Connection connection;

		//List of matters to process
		//Statement statement0 = null;
		ResultSet resultset0 = null;

		//List of matter keys and templates to process
		//Statement statement1 = null;
		ResultSet resultset1 = null;

		//Used to update table CMFT_BASE setting process to N and update date processed and processed by
		//Statement statement2 = null;
		ResultSet resultset2 = null;

		DbBean db;
		db=new DbBean();
		
		try {
			db.connect();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

		/*
		// Using JDBC
		OracleDataSource ods;
		ods = new OracleDataSource();

		//Production
		//String url = "jdbc:oracle:thin:@//eagnmntwe189c:1521/plawdb.usps.gov";
		//Development
		String url = "jdbc:oracle:thin:@eagnmnsxn41:1521/dlawdb";
		//CAT
		//String url = "jdbc:oracle:thin:@eagnmnss06e:1521/qlawdb";
		//Test
		//String url = "jdbc:oracle:thin:@56.64.80.197:1521/tlawdb";

		ods.setURL(url);
		ods.setUser("lawmanager");
		ods.setPassword("xxxxxxxx");
		connection = ods.getConnection();

		//End of Database connection statements
		//***************************************************************************************************
		*/

		//Set cRunProcess to Y if templates are found to run
		boolean lRunProcess = false;

		//String cMatterKey = "606517";
		String cMatterKey = "";
		String cMatterNumber = "";
		String cMatterName = "";
		String cBaseKey = "";
		String cCompBaseKey = "";
		String cEmailAddr = "";

		//Query CMFT_BASE to see if there are any matter keys to be processed
		String cSQL00 = "select a.base_key,a.updated_by,a.date_updated ";
		cSQL00 = cSQL00 +"from cmft_base a "; 
		cSQL00 = cSQL00 +"where a.process = 'Y' ";
		//Used if being passed a matter key from CGI
		//cSQL01 = cSQL01 +"and a.matter_key = '"+cMatterKey"' ";
		cSQL00 = cSQL00 +"order by a.date_updated";

		try {
			//statement0 = connection.createStatement();
			//resultset0 = statement0.executeQuery(cSQL00);
			
			resultset0 = DbBean.execSQL(cSQL00);
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//Go through list of matter keys to process
		while (resultset0.next()) {
			cBaseKey = resultset0.getString("base_key");

			if (Load_File.lTest) System.out.println("Matter to process base key: "+cBaseKey); 


			//Query all templates by base key to be process
			String cSQL01 = "select a.base_key,a.updated_by,b.template_key,c.template_folder,c.template_name,d.matter_number,d.matter_name,d.matter_key,f.eaddress ";
			cSQL01 = cSQL01 +"from cmft_base a, cmft_selected_templates b, cmft_templates c, matter d, personnel e, eaddress f "; 
			cSQL01 = cSQL01 +"where a.process = 'Y' ";
			cSQL01 = cSQL01 +"and a.base_key = '"+cBaseKey+"' ";
			cSQL01 = cSQL01 +"and a.matter_key = d.matter_key ";
			cSQL01 = cSQL01 +"and a.base_key = b.base_key ";
			cSQL01 = cSQL01 +"and b.template_key = c.template_key ";
			cSQL01 = cSQL01 +"and a.updated_by = e.personnel_key ";
			cSQL01 = cSQL01 +"and e.object_key = f.entity_key "; 
			cSQL01 = cSQL01 +"order by a.base_key";

			try {
				//statement1 = connection.createStatement();
				//resultset1 = statement1.executeQuery(cSQL01);
				resultset1 = DbBean.execSQL(cSQL01);


			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//Query dynamic templates by base key to be process
			String cSQL02 = "select a.base_key,a.updated_by,b.template_key,c.template_folder,c.template_name,d.matter_number,d.matter_name,d.matter_key,f.eaddress ";
			cSQL02 = cSQL02 +"from cmft_base a, cmft_dynamic_templates b, cmft_templates c, matter d, personnel e, eaddress f "; 
			cSQL02 = cSQL02 +"where a.process = 'Y' ";
			cSQL02 = cSQL02 +"and a.base_key = '"+cBaseKey+"' ";
			cSQL02 = cSQL02 +"and a.matter_key = d.matter_key ";
			cSQL02 = cSQL02 +"and a.base_key = b.base_key ";
			cSQL02 = cSQL02 +"and b.template_key = c.template_key ";
			cSQL02 = cSQL02 +"and a.updated_by = e.personnel_key ";
			cSQL02 = cSQL02 +"and e.object_key = f.entity_key "; 
			cSQL02 = cSQL02 +"order by a.base_key";

			try {
				//statement1 = connection.createStatement();
				//resultset1 = statement1.executeQuery(cSQL01);
				resultset2 = DbBean.execSQL(cSQL02);


			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Go through list of dynamic templates to process by matter key
			while (resultset2.next()) {
				
		        String[] aMergeArray;
		        aMergeArray = new String[1];

				cMatterNumber = resultset2.getString("matter_number");
				
				aMergeArray[0]=cMatterNumber;
				
				try {
					Merge_Files.main(aMergeArray);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}

			//Used to hold list of templates temporarily
			List<String> strList0 = new ArrayList<String>();

			//Used to hold list of all templates processed
			List<String> strListNameOnly = new ArrayList<String>();
			

			//Used to hold variables with values (moved to ProcessBase)
			//List<String> strList = new ArrayList<String>();

			boolean lFirstRow = true;
			
			//Go through list of templates to process by matter key
			while (resultset1.next()) {
				lRunProcess = true;
				
				cEmailAddr = resultset1.getString("eaddress");
				cMatterNumber = resultset1.getString("matter_number");
				cMatterName = resultset1.getString("matter_name");

				strListNameOnly.add(resultset1.getString("template_name"));
				
				strList0.clear();

				strList0.add(resultset1.getString("template_folder"));
				strList0.add(resultset1.getString("template_name"));
				strList0.add(resultset1.getString("template_key"));
				strList0.add(resultset1.getString("matter_number"));
				strList0.add(resultset1.getString("matter_name"));
				strList0.add(resultset1.getString("matter_key"));
				
				if (lFirstRow) {
					lFirstRow = false;
					
					File theDir = new File("processed\\"+cMatterNumber);  // Defining Directory/Folder Name  
					try{   
						if (!theDir.exists()){  // Checks that Directory/Folder Doesn't Exists!  
							boolean result = theDir.mkdir();    
							if(result){  
								//JOptionPane.showMessageDialog(null, "New Folder created!");
							}  
						} 
						else
						{
							//Delete all files in Directory
							File[] files = theDir.listFiles();
							for(int i=0; i<files.length; i++) {
								if (Load_File.lTest) System.out.println("|||||||||||||||||File Deleted: "+files[i]+"|||||||||||||||||"); 
								files[i].delete();
							}			

						}
					}catch(Exception e){  
						JOptionPane.showMessageDialog(null, e);  
					}  		
					
				}
				

				ProcessBase.process(strList0);
			}
			
			if (lRunProcess) {

		        String[] aZipArray;
		        aZipArray = new String[3];
		        
		        cMatterNumber = strList0.get(3);
		        aZipArray[0] = "processed\\"+cMatterNumber;
		        aZipArray[1] = "processed\\"+cMatterNumber+".zip";
		        //Password before made easy by request from users SF201140861
		        //aZipArray[2] = "cmft!"+cMatterNumber.substring(0,2)+cMatterNumber.substring(6);
		        //was cmft!SF40861 not LLSF2011
		        aZipArray[2] = "LL"+cMatterNumber.substring(0,6);

		        
				/*	
				 * 
				 * GAC - Not needed since we are doing all zip routines within Java
				Run batch file, this may be used to zip the contents of directory where the output files have been placed
				String path="cmd /c start d:\\sample\\sample.bat";
				Runtime rn=Runtime.getRuntime();
				Process pr=rn.exec(path);`
	
				GAC - No longer needed since we are now using an open source library Zip4j which includes encryption and password protection
				which the standard Java library does not. 
		        //Zip_Folder.main(aZipArray);
	            */
		        
				ZipPassFolder.main(aZipArray,strListNameOnly);
				
				// declares an array of integers
		        String[] aMailArray;
	
		        // allocates memory for 4 Strings
		        aMailArray = new String[4];
		        aMailArray[0]=cEmailAddr;
		        aMailArray[1]=cMatterNumber;
		        aMailArray[2]=cMatterName;
		        aMailArray[3]=aZipArray[1];
	
		        
				if (lEmail){
				Send_Mail.SendMail(aMailArray,strListNameOnly);
				}
				
	
				//Update table CMFT_BASE setting process to N and update date processed and processed by
				String cSQL03 = "update cmft_base set  process = 'N', date_processed=sysdate, processed_by = 100000 where base_key = "+cBaseKey;
	
				try {
					//statement2 = connection.createStatement();
					//resultset2 = statement2.executeQuery(cSQL03);
					resultset2 = DbBean.execSQL(cSQL03);
	
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				strListNameOnly.clear();
			}
		}
	}
}

