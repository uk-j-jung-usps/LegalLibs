package base;

import java.sql.*;  

public class DbBean implements java.io.Serializable{

  //Production Database
  //String dbURL = "jdbc:oracle:thin:@//eagnmntwe189c:1521/plawdb.usps.gov";
	
  //CAT Database	
  String dbURL = "jdbc:oracle:thin:@//eagnmnss06e:1521/qlawdb";

  //Development Database
  //String dbURL = "jdbc:oracle:thin:@//eagnmnsxn41:1521/dlawdb";
	
	//Local Database
  //String dbURL = "jdbc:oracle:thin:@//wadchqgc-devl2:1521/tlawdb";
  
  

  String dbDriver = "oracle.jdbc.driver.OracleDriver"; 

  String dbUserID = "lawmanager";
  String dbPassword = "zaq1xsw2";

  public boolean lTest = false;
  
  private static Connection dbCon;
  
  public DbBean(){  
   super();    
   }

  public boolean connect() throws ClassNotFoundException,SQLException{ 
	Class.forName(dbDriver); 
	dbCon = DriverManager.getConnection(dbURL,dbUserID,dbPassword );	
	
    return true; 
  }
 

  public void close() throws SQLException{ 
  dbCon.close(); 
   }

  public static ResultSet execSQL(String sql) throws SQLException{
	  
	  if (Load_File.lTest) System.out.println("||||||||||||||||||||||||||DbBean - ResultSet||||||||||||||||||||||||||||||||||||||"); 
  

  Statement s = dbCon.createStatement(); 
  ResultSet r = s.executeQuery(sql); 
  return (r == null) ? null : r; 
  }

  public int updateSQL(String sql) throws SQLException{   
     Statement s = dbCon.createStatement();
   int r = s.executeUpdate(sql);
   return (r == 0) ? 0 : r; 
  }

} 