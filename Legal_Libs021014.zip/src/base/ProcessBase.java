package base;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class ProcessBase {

	/**
	 * @param args
	 */
	public static void process(List<String> strList0) {

		// TODO Auto-generated method stub

		//strList0-0: template_folder
		//strList0-1: template_name
		//strList0-2: template_key
		//strList0-3: matter_number
		//strList0-4: matter_name
		//strList0-5: matter_key

		String cFolder = "";
		String cFile = "";
		String cMatterKey="";
		String cMatterNumber="";

		cFolder = strList0.get(0);
		cFile = strList0.get(1);
		cMatterKey = strList0.get(5);

		cMatterNumber = strList0.get(3);
		
		DbBean db;
		db=new DbBean();

		try {
			db.connect();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if (Load_File.lTest) System.out.println("||||||||||||||||||||||||||Process Base||||||||||||||||||||||||||||||||||||||"); 

		//May want to add table that will limit the variable pairs to the specific template being processed
		String cSQL02 = "select a.tempvar_key_name,a.tempvar_value ";
		cSQL02 = cSQL02 +"from cmft_matterkey_pairs a "; 
		cSQL02 = cSQL02 +"where a.matter_key = '"+cMatterKey+"'";

		//List of key/pairs
		ResultSet resultset = null;

		//Used to hold variables with values
		List<String> strList = new ArrayList<String>();

		try {

			resultset = DbBean.execSQL(cSQL02);
			
			String cValue = "";
			
			while (resultset.next()) {
				strList.add("%"+resultset.getString("tempvar_key_name")+"%");
				
				//GAC - added so we insert blank versus null when field is empty
				cValue = resultset.getString("tempvar_value");
				if (cValue == null) {
					cValue = " ";
				}
					
				strList.add(cValue);

				if (Load_File.lTest) System.out.println("%"+resultset.getString("tempvar_key_name")+"%");
				if (Load_File.lTest) System.out.println(resultset.getString("tempvar_value"));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String[] strArray = new String[strList.size()];
		strArray = strList.toArray(strArray);

		try {
			ReadValues.ReplaceStr(cMatterNumber,cFolder,cFile,strArray);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
