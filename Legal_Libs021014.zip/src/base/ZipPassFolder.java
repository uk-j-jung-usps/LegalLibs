package base;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

public class ZipPassFolder {

/*
 * Copyright 2010 Srikanth Reddy Lingala  
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, 
 * software distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 */


/**
 * Demonstrates adding files to zip file with AES Encryption
 *
 * @author Srikanth Reddy Lingala
 */
	
    List<String> fileList;
    //private static final String OUTPUT_ZIP_FILE = "Folder.zip";
    //private static final String SOURCE_FOLDER = "D:\\Reports"; //SourceFolder path

    private static String OUTPUT_ZIP_FILE;
    private static String SOURCE_FOLDER; //SourceFolder path
    private static String ZIPPASSWORD;
	
	public static void main(String[] args,List<String> strListTemps) {
		
		//Added extra
		//Zip_Folder appZip = new Zip_Folder();
    	
    	SOURCE_FOLDER=args[0];
    	OUTPUT_ZIP_FILE=args[1];
    	ZIPPASSWORD=args[2];
    	
		//End added extra
        
		new ZipPassFolder(strListTemps);
	}
	
	public ZipPassFolder(List<String> strListTemps) {
		
		try {
			// Initiate ZipFile object with the path/name of the zip file.
			//ZipFile zipFile = new ZipFile("c:\\ZipTest\\AddFilesWithAESZipEncryption.zip");
			
			//ZipFile zipFile = new ZipFile("C:\\Developer Share\\Java_Apps\\String_Replace\\processed\\SF201211297.zip");
			//ZipFile zipFile = new ZipFile(SOURCE_FOLDER+"\\"+OUTPUT_ZIP_FILE);
			//ZipFile zipFile = new ZipFile(SOURCE_FOLDER);
			

			System.out.println("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
			System.out.println("Name of Source Folder: "+SOURCE_FOLDER);
			System.out.println("Name of ZipFile: "+OUTPUT_ZIP_FILE);
			System.out.println("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
			
			
			
			File zipfile = new File(OUTPUT_ZIP_FILE);
			
			if (Load_File.lTest) {
				System.out.println("Name of ZipFile: "+zipfile.getName());
			}
			
			if (zipfile.exists()){
			 
	    		if(zipfile.delete()){
	    			if (Load_File.lTest) {
	    			System.out.println(zipfile.getName() + " is deleted!");
	    			}
    			} else {
    				if (Load_File.lTest) {
    					System.out.println("Delete operation is failed.");
    				}
	    		}			
			}
			
			ZipFile zipFile = new ZipFile(OUTPUT_ZIP_FILE);
			
			/*
			 * Only needed if adding files individually via zipFile.addFiles(filesToAdd, parameters)
			
			// Build the list of files to be added in the array list
			// Objects of type File have to be added to the ArrayList
			ArrayList filesToAdd = new ArrayList();
			//filesToAdd.add(new File("c:\\ZipTest\\sample.txt"));
			//filesToAdd.add(new File("c:\\ZipTest\\myvideo.avi"));
			//filesToAdd.add(new File("c:\\ZipTest\\mysong.mp3"));
			
			if (strListTemps.size() > 0) {
				// Loop through arraylist to list all templates processed
				for (int i = 0; i <= strListTemps.size() - 1; i++) {
					filesToAdd.add(new File(SOURCE_FOLDER+"\\"+strListTemps.get(i)));
				}
			}
			*/
			
			
			//filesToAdd.add(new File("C:\\Developer Share\\Java_Apps\\String_Replace\\processed\\SF201211297\\Discovery - [FOR SF USE ONLY] - Agency's Standard Medical Release Forms for Discovery .rtf"));
			//filesToAdd.add(new File("C:\\Developer Share\\Java_Apps\\String_Replace\\processed\\SF201211297\\PS Form 8041 Request for Settlement Check.rtf"));
			//filesToAdd.add(new File("C:\\Developer Share\\Java_Apps\\String_Replace\\processed\\SF201211297\\Staff Notes - EEOC deadlines.rtf"));
			
			
			// Initiate Zip Parameters which define various properties such
			// as compression method, etc. More parameters are explained in other
			// examples
			ZipParameters parameters = new ZipParameters();
			
			//Adding optional parameters
			//parameters.setFileNameInZip(OUTPUT_ZIP_FILE);
			//parameters.setIncludeRootFolder(false);
			//parameters.setDefaultFolderPath(SOURCE_FOLDER);
	
			
			parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE); // set compression method to deflate compression
			
			// Set the compression level. This value has to be in between 0 to 9
			// Several predefined compression levels are available
			// DEFLATE_LEVEL_FASTEST - Lowest compression level but higher speed of compression
			// DEFLATE_LEVEL_FAST - Low compression level but higher speed of compression
			// DEFLATE_LEVEL_NORMAL - Optimal balance between compression level/speed
			// DEFLATE_LEVEL_MAXIMUM - High compression level with a compromise of speed
			// DEFLATE_LEVEL_ULTRA - Highest compression level but low speed
			parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL); 
			
			// Set the encryption flag to true
			// If this is set to false, then the rest of encryption properties are ignored
			parameters.setEncryptFiles(true);
			
			// Set the encryption method to AES Zip Encryption
			parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
			
			// Set AES Key strength. Key strengths available for AES encryption are:
			// AES_STRENGTH_128 - For both encryption and decryption
			// AES_STRENGTH_192 - For decryption only
			// AES_STRENGTH_256 - For both encryption and decryption
			// Key strength 192 cannot be used for encryption. But if a zip file already has a
			// file encrypted with key strength of 192, then Zip4j can decrypt this file
			parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
			
			// Set password
			//parameters.setPassword("test123!");
			parameters.setPassword(ZIPPASSWORD);

			if (Load_File.lTest) {
				System.out.println("========================================================================================"); 
				System.out.println("========================================================================================"); 
				System.out.println("Password = "+ZIPPASSWORD); 
				System.out.println("========================================================================================"); 
				System.out.println("========================================================================================"); 
			}
			
			// Now add files to the zip file
			// Note: To add a single file, the method addFile can be used
			// Note: If the zip file already exists and if this zip file is a split file
			// then this method throws an exception as Zip Format Specification does not 
			// allow updating split zip files
			// GAC - this adds individual files to the zip file
			//zipFile.addFiles(filesToAdd, parameters);
			
			// GAC - this adds the entire folder worth of zip files
			zipFile.addFolder(SOURCE_FOLDER, parameters);
			
		} catch (ZipException e) {
			e.printStackTrace();
		}
	}
}
