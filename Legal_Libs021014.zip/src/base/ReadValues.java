package base;

import java.io.*;
import java.util.regex.Pattern;

public class ReadValues {

	public static void ReplaceStr(String cMatterNumber, String cFolder, String cReadFile ,String[] args) throws IOException {
		
		//boolean lTest = false;
		boolean lTempVars = false;

		String str="";

		// String keyName = "%AJ_LN%";
		// String value = "Castle";
		
		/*
		String keyName = args[0];
		String value = args[1];
		String cFileSuffix = args[2];
		String cFirstRun = args[3];
		*/

		//Passed parameters are cFolder and cReadFile so no longer needed
		//String cFolder= args0[0];
		//String cReadFile = args0[1];
		
		String keyName = "";
		String value = "";
		//String cFileSuffix = "";
		//String cFirstRun = "";
		
		int nArrayLen = args.length;
		
		if (Load_File.lTest) System.out.println("args length: "+nArrayLen);
		
		String strTest;

		// reader
		String readFile = "";
		String writeFile = "";
		
		//cFirstRun = "1";
		
		//readFile = "Fax Cover Sheet - AJ.rtf";
		//readFile = "templates\\Discovery - Agency Discovery w Medical Forms.rtf";
		//writeFile = "resultFile.rtf";
		//writeFile = "processed\\"+cReadFile;
		writeFile = "processed\\"+cMatterNumber+"\\"+cReadFile;		
		

		/*
		if (cFirstRun.equals("1")) {
			readFile = "Fax Cover Sheet - AJ.rtf";
			readFile = "templates\\Discovery - Agency Discovery w Medical Forms.rtf";

			
			writeFile = "resultFile1.rtf";
			
		}
		else {
			if (cFileSuffix.equals("1")) {
				readFile = "resultFile0.rtf";
				// writer
				writeFile = "resultFile1.rtf";
				
			} else {
				readFile = "resultFile1.rtf";
				// writer
				writeFile = "resultFile0.rtf";
			}
		}
		*/

		readFile = cFolder+"\\"+cReadFile;
		if (lTempVars) {
			System.out.println("**************************************************************");
			System.out.println("File to Read: "+readFile+"...");
			System.out.println("**************************************************************");
		}

		strTest = readFile(readFile);
		
		if (Load_File.lTest) System.out.println("**************************************************************");
		//System.out.println(strTest);
		if (Load_File.lTest) System.out.println("**************************************************************");

		BufferedWriter bw = new BufferedWriter(new FileWriter(writeFile));

		int x = 0;
		int y = 0;
		StringBuilder result = new StringBuilder();

		
		for (int i = 0; i < nArrayLen; i++) {
			
			if (i != 0){
				x = 0;
				y = 0;

				result = null;
				result = new StringBuilder();
			
			}
			
			keyName = args[i];

			i++;
			value = args[i];
			//System.out.println("KeyName: "+keyName+"\tValue: "+value);

			//i++;
			//cFirstRun = args[i];
			
			
			while ((x = strTest.indexOf(keyName, y)) > -1) {
				result.append(strTest, y, x);
				result.append(value);
				y = x + keyName.length();
				if (lTempVars) System.out.println("KeyName Found: "+keyName+"\tValue: "+value);			

			}
		
			
			
			result.append(strTest, y, strTest.length());
			
			str = result.toString();
			strTest = str;
			
		
		}		
		
		
		//Pattern.compile(value).matcher(result).replaceAll(keyName);

		
		/*
		while ((x = strTest.indexOf(keyName, y)) > -1) {
			result.append(strTest, y, x);
			result.append(value);
			y = x + keyName.length();
		}
	
		result.append(strTest, y, strTest.length());
		
		str = result.toString();
		strTest = str;

		result = null;
		result = new StringBuilder();
		
		x = 0;
		y = 0;
		
		keyName="%COMP_LN%";
		value="Gheta";
		
		while ((x = strTest.indexOf(keyName, y)) > -1) {
			result.append(strTest, y, x);
			result.append(value);
			y = x + keyName.length();
		}

		result.append(strTest, y, strTest.length());


		str = result.toString();

		*/


		str = str + "\n";
		
		// write result to destination file.
		bw.write(str);
		//bw.write(strTest);
		
		// must close file when done.
		bw.close();
		
		if (Load_File.lTest) System.out.println("After writer closed...");


	} // end of main.

	public static String readFile(String file) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line = null;
		StringBuilder stringBuilder = new StringBuilder();
		String ls = System.getProperty("line.separator");
		while ((line = reader.readLine()) != null) {
			stringBuilder.append(line);
			stringBuilder.append(ls);
		}
		//GAC - Added, was not in original code
		reader.close();

		boolean lTest = false;
		if (lTest) System.out.println("After reader closed...");
		
		return stringBuilder.toString();
	}
}