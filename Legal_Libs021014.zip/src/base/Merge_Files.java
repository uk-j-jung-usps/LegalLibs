package base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Merge_Files {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		//String cMatterNo = args[0];
		
		//if (Load_File.lTest) System.out.println("In Merge Files for "+cMatterNo); 
		
	    String []filename=
	    	{
	    		
	    		"templates\\dynamic\\Top_Discovery - Agency's Standard Discovery Responses.txt",

	    		"templates\\dynamic\\first_inter.txt",

	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",
	    		"templates\\dynamic\\more_inters.txt",

	    		"templates\\dynamic\\first_request.txt",

	    		"templates\\dynamic\\more_requests.txt",
	    		"templates\\dynamic\\more_requests.txt",
	    		"templates\\dynamic\\more_requests.txt",
	    		"templates\\dynamic\\more_requests.txt",
	    		"templates\\dynamic\\more_requests.txt",
	    		"templates\\dynamic\\more_requests.txt",
	    		"templates\\dynamic\\more_requests.txt",
	    		"templates\\dynamic\\more_requests.txt",
	    		"templates\\dynamic\\more_requests.txt",

	    		"templates\\dynamic\\first_document.txt",

	    		"templates\\dynamic\\more_documents.txt",
	    		"templates\\dynamic\\more_documents.txt",
	    		"templates\\dynamic\\more_documents.txt",
	    		"templates\\dynamic\\more_documents.txt",
	    		"templates\\dynamic\\more_documents.txt",
	    		"templates\\dynamic\\more_documents.txt",
	    		"templates\\dynamic\\more_documents.txt",
	    		"templates\\dynamic\\more_documents.txt",
	    		"templates\\dynamic\\more_documents.txt",

	    		"templates\\dynamic\\Bot_Discovery - Agency's Standard Discovery Responses.txt",

	    };
	    
	    File file=new File("templates\\dynamic\\Discovery - Agency's Standard Discovery Responses Consolidated.rtf");
	    FileWriter output = null;
		try {
			output = new FileWriter(file);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    try
	    {   
	      for(int i=0;i<filename.length;i++)
	      {
	    	  
	    	if (Load_File.lTest) System.out.println("In Merge Files - loop "+i); 	    	  
	        
	    	BufferedReader objBufferedReader = new BufferedReader(new FileReader(getDictionaryFilePath(filename[i])));

	        String line;
	        while ((line = objBufferedReader.readLine())!=null )
	        {
	          //line=line.replace(" ","");

	          output.write(line);
	        }
	        objBufferedReader.close();
	      }
	      output.close();
	    }
	    catch (Exception e) 
	    {
	      throw new Exception (e);
	    }
	  }

	  public static String getDictionaryFilePath(String filename) throws Exception
	  {
	    String dictionaryFolderPath = null;
	    File configFolder = new File(filename);
	    try 
	    {
	      dictionaryFolderPath = configFolder.getAbsolutePath();
	    } 
	    catch (Exception e) 
	    {
	      throw new Exception (e);
	    }
	    return dictionaryFolderPath;
	  }

	}


