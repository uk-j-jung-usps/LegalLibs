package base;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class Send_Mail {

	/**
	 * @param args
	 */
	static void SendMail(String[] args, List<String> strListTemps) {
		// static String msgText1 = "This is a message body.\nHere's line two.";
		// static String msgText2 = "This is the text in the message
		// attachment.";
		// public static void main(String[] args) {
		/*
		 * if (args.length != 4) { System.out.println( "usage: java msgmultisend
		 * <to> <from> <smtp> true|false"); return; }
		 */
		String to = args[0];
		//boolean debug = Boolean.valueOf(args[3]).booleanValue();
		//String cMatterNumber = "SF201399999";
		//String cMatterName = "Matter name is Test Matter out of San Francisco";

		String cMatterNumber = args[1];
		String cMatterName = args[2];
		String cZip_File = args[3];
		
		//////////
		ArrayList<String> cfile_names = new ArrayList();
		cfile_names.add("");
		/////////////		
	
	
		// Change cTest to Y to see debugging info in console
		// Also need to update cTest in Main function
		String cTest = "N";
	
		//aqua #09AFE5
		//tan #DBD1B0
		//red text #990000
		//light aqua #DAE8EC
		
		String msgText1 = "<body bgcolor='#DAE8EC'><font style='font-family:Arial, Helvetica, sans-serif' color='#09AFE5' size='+1'>";
		//msgText1 = msgText1+"<center><img src='https://eagnmnss00c/DiscoveryRequest/img/LLSmall.gif' alt='Legal Libs Logo'></center>"; 
		//msgText1 = msgText1+"<center><img src='C:\\Java_Apps\\CMFT\\LLSmall.gif' alt='Legal Libs Logo'></center>"; 
		msgText1 = msgText1+"<center><img src=\"cid:the-img-1\"/></center>";
		msgText1 = msgText1+"<center><i>Templates</i></center>";
		java.util.Date date = new java.util.Date();
	
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String cCurDate = formatter.format(date);
	
		String msgText2 = "</font><font style='font-family:Arial, Helvetica, sans-serif' color='#000000' size='-1'><br><br>Date Processed:&nbsp;&nbsp;"
			+ cCurDate;
		String msgText3 = "<br><br>";
		String msgText4 = "The attached password protected zip file contains the following templates that have been processed for matter number <b>"+cMatterNumber+"</b> with the matter name of <b>"+cMatterName+":</b><br><br>";
		
		String msgLine = "<br>__________________________________________________________________________________________";
	
		String from = "BPJGF0@usps.gov";
		String host = "mailrelay.usps.gov";
		boolean debug = false;
	
		if (cTest == "Y") {
			System.out.print("In LM_Send");
			System.out.print("\t");
		}
	
		// create some properties and get the default Session
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		Session session = Session.getInstance(props, null);
		session.setDebug(debug);
		try {
			// create a message
			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(from));
			InternetAddress[] address = { new InternetAddress(to) };
			msg.setRecipients(Message.RecipientType.TO, address);
			msg.setSubject(cMatterNumber+" - Legal Libs Templates Processed");
			// msg.setSentDate(new date());
			// java.util.Date date = new
			// java.util.Date(System.currentTimeMillis());
			// java.util.Date date = new java.util.Date();
			msg.setSentDate(date);
			// create and fill the first message part
			MimeBodyPart mbp1 = new MimeBodyPart();
	
			// \n new line, \r carriage return
			// A carriage-return character followed immediately by a newline
			// character ("\r\n")
	
			String msgText = msgText1 + "\r\n\r\n" + msgText2 + "\r\n\r\n"
			+ msgText3 + "\r\n\r\n" + msgText4 + "\r\n\r\n";

			if (strListTemps.size() > 0) {
				// Loop through arraylist to list all templates processed
				for (int i = 0; i <= strListTemps.size() - 1; i++) {
					msgText = msgText+strListTemps.get(i)+"<br>";
				}
			}

			// Begin Image part
			BodyPart imgPart=new MimeBodyPart();
			 
	        // Loading the image
	        //DataSource ds=new FileDataSource("C:\\Java_Apps\\CMFT\\LLSmall.gif");
	        DataSource ds=new FileDataSource("LLSmall.gif");	        
	        imgPart.setDataHandler(new DataHandler(ds));

	        //Setting the header
	        imgPart.setHeader("Content-ID","the-img-1");
	       
			// End Image part
			
			
			mbp1.setContent(msgText, "text/html");
	
			// create the Multipart and its parts to it
			// added parameter related for adding embeded image.  Otherwise would be ()
			Multipart mp = new MimeMultipart("related");
			
	        // attaching the multi-part to the message
			msg.setContent(mp);
			
			//Add Text
			mp.addBodyPart(mbp1);

			//Add Image part
			mp.addBodyPart(imgPart);			
			
			// create and fill the second message part MimeBodyPart mbp2
			MimeBodyPart mbpx = new MimeBodyPart();
			// attach the file to the message
			FileDataSource fds = new FileDataSource(cZip_File);
			mbpx.setDataHandler(new DataHandler(fds));
			mbpx.setFileName(fds.getName());

			mp.addBodyPart(mbpx);
			
			
			/*
	
			if (strListTemps.size() > 0) {
	
				/*
				 * // create and fill the second message part MimeBodyPart mbp2
				 * = new MimeBodyPart(); // attach the file to the message
				 * FileDataSource fds = new
				 * FileDataSource("S:\\kywqh2\\Desktop\\GREG090110.doc");
				 * mbp2.setDataHandler(new DataHandler(fds));
				 * mbp2.setFileName(fds.getName());
				 * 
				 * mp.addBodyPart(mbp2);
				 */
			/*
				// Loop through arraylist for all available files to attach
				for (int i = 0; i <= strListTemps.size() - 1; i++) {
	
					// create and fill the third message part
					MimeBodyPart mbpx = new MimeBodyPart();
					// attach the file to the message
					FileDataSource fds = new FileDataSource(cfile_names.get(i));
					mbpx.setDataHandler(new DataHandler(fds));
					mbpx.setFileName(fds.getName());
	
					mp.addBodyPart(mbpx);
	
				}
	
			}
			*/
	
			// add the Multipart to the message
			// msg.setContent(mp);
			// msg.setContent("<h1>"+mp+"</h1>", "text/html");
			msg.setContent(mp);
	
			// send the message
			Transport.send(msg);
		} catch (MessagingException mex) {
			mex.printStackTrace();
			Exception ex = null;
			if ((ex = mex.getNextException()) != null) {
				ex.printStackTrace();
			}
		}
	}
}



